module.exports = {

"[project]/app/layout.tsx [app-rsc] (ecmascript)": (function(__turbopack_context__) {

var { g: global, d: __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),

};

//# sourceMappingURL=app_layout_tsx_4d447237._.js.map