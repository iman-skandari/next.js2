(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_f22e3ef3._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_f22e3ef3._.js",
  "chunks": [
    "static/chunks/_5fd711bf._.js",
    "static/chunks/app_userList_module_540febc4.css"
  ],
  "source": "dynamic"
});
