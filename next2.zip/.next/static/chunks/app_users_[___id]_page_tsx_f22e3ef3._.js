(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_users_[___id]_page_tsx_f22e3ef3._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_users_[___id]_page_tsx_f22e3ef3._.js",
  "chunks": [
    "static/chunks/_4c3af5a5._.js",
    "static/chunks/app_users_[___id]_userDetail_module_d5a70648.css"
  ],
  "source": "dynamic"
});
